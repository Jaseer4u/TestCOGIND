/**
 *
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullStandComponent } from './fullstand.component';

describe('FullStandComponent', () => {
  let component: FullStandComponent;
  let fixture: ComponentFixture<FullStandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullStandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullStandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

/**
 *
 */