/**
 *
 */
 import { Component, OnInit } from '@angular/core';
 import {Validators, FormBuilder, FormGroup} from '@angular/forms';
 import { RouterModule, Routes ,Router,ActivatedRoute} from '@angular/router';

 // Services
 import { ValidationService } from '../../../services/config/config.service';
 import { VollService } from '../../../services/vollvoll.service';
 import { routerTransition } from '../../../services/config/config.service';

 import { ToastrService } from 'ngx-toastr';

 @Component({
 	selector: 'app-student-add',
 	templateUrl: './fullstand.component.html',
 	styleUrls: ['./fullstand.component.css'],
 	animations: [routerTransition()],
 	host: {'[@routerTransition]': ''}
 })

 export class StudentAddComponent implements OnInit {
 	// create studentAddForm of type FormGroup
 	private vollall : FormGroup;
 	index:any;

 	constructor(private formBuilder: FormBuilder,private router: Router, private route: ActivatedRoute, private studentService:StudentService,private toastr: ToastrService) {

 		// Check for route params
 		this.route.params.subscribe(params => {
 			this.index = params['id'];
 			// check if ID exists in route & call update or add methods accordingly
 			if (this.index && this.index != null && this.index != undefined) {
 				// Get URL
 			}else{
 				this.createForm(null);
 			}
 		});
 	}

 	ngOnInit() {
 	}

/**
 *
 */